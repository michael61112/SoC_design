
#ifndef __MULTIPLICATION_H__
#define __MULTIPLICATION_H__

typedef signed int int32_t;

void multip_2num(int32_t n32In1, int32_t n32In2, int32_t* pn32ResOut);

#endif
